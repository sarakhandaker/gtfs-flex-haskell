# Changelog for frequency

## Unreleased changes
